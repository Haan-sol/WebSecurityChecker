import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class db_test{
	public static void main(String[] args) throws Exception{
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/food_db","admin","1234");
			System.out.println("connection = " + conn);
			
			stmt = conn.prepareStatement("show databases");
			rs = stmt.executeQuery();
		} catch(Exception e) {
			System.out.println("catch");

			e.printStackTrace();
		}
	}
}