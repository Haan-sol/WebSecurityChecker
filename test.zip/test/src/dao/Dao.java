package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.Dto;

public class Dao{
	Connection conn = null;
	PreparedStatement preparedStatement = null;
	ResultSet rs = null;
	
	public Dao() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/food_db","admin","1234");
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("Dao catch");
		}
	}
	
	public void modify(int id, String type, String name, int price, String location, boolean single, boolean delivery, int portion, String phone, String address, String imgFile, int victory) {
	
		try {
			String query = "update food_info set type = ?, name = ?, price = ?, location = ?, single = ?, delivery = ?, portion = ?, phone = ?, address = ?, imgFile = ?, victory = ? where id = ?";
			preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1, type);
			preparedStatement.setString(2, name);
			preparedStatement.setInt(3, price);
			preparedStatement.setString(4, location);
			preparedStatement.setBoolean(5, single);
			preparedStatement.setBoolean(6, delivery);
			preparedStatement.setInt(7, portion);
			preparedStatement.setString(8, phone);
			preparedStatement.setString(9, address);
			preparedStatement.setString(10, imgFile);
			preparedStatement.setInt(11, victory);
			preparedStatement.setInt(12, id);
			int rn = preparedStatement.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(conn != null) conn.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}	
		} 
	
	}
	
	
	
	public void write(String type, String name, int price, String location, boolean single, boolean delivery, int portion, String phone, String address, String imgFile) {
		try {
			String query = "insert into food_info (type, name, price, location, single, delivery, portion, phone, address, imgFile, victory) values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
			preparedStatement = conn.prepareStatement(query);
			preparedStatement.setString(1, type);
			preparedStatement.setString(2, name);
			preparedStatement.setInt(3, price);
			preparedStatement.setString(4, location);
			preparedStatement.setBoolean(5, single);
			preparedStatement.setBoolean(6, delivery);
			preparedStatement.setInt(7, portion);
			preparedStatement.setString(8, phone);
			preparedStatement.setString(9, address);
			preparedStatement.setString(10, imgFile);
			int rn = preparedStatement.executeUpdate();
		
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(conn != null) conn.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}	
		} 
	}
	
	public ArrayList<Dto> list(){
		ArrayList<Dto> dtos = new ArrayList<Dto>();
		ResultSet resultSet = null;
		
		try {
			String query = "select id, type, name, price, location, single, delivery, portion, phone, address, imgFile, victory from food_info";
			preparedStatement = conn.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String type = resultSet.getString("type");
				String name = resultSet.getString("name");
				int price = resultSet.getInt("price");
				String location = resultSet.getString("location");
				boolean single = resultSet.getBoolean("single");
				boolean delivery = resultSet.getBoolean("delivery");
				int portion = resultSet.getInt("portion");
				String phone = resultSet.getString("phone");
				String address = resultSet.getString("address");
				String imgFile = resultSet.getString("imgFile");
				int victory = resultSet.getInt("victory");
			
				Dto dto = new Dto(id, type, name, price, location, single, delivery, portion, phone, address, imgFile, victory);
				dtos.add(dto);
			}
		} catch(Exception e) {
			System.out.println("list catch");
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(conn != null) conn.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}	
		} 
		return dtos;
	}
	
	public Dto content(String strID) {
		Dto dto = null;
		ResultSet resultSet = null;
		
		try {
			String query = "select * from food_info where id = ?";
			preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(strID));
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()) {
				int id = resultSet.getInt("id");
				String type = resultSet.getString("type");
				String name = resultSet.getString("name");
				int price = resultSet.getInt("price");
				String location = resultSet.getString("location");
				boolean single = resultSet.getBoolean("single");
				boolean delivery = resultSet.getBoolean("delivery");
				int portion = resultSet.getInt("portion");
				String phone = resultSet.getString("phone");
				String address = resultSet.getString("address");
				String imgFile = resultSet.getString("imgFile");
				int victory = resultSet.getInt("victory");
			
				dto = new Dto(id, type, name, price, location, single, delivery, portion, phone, address, imgFile, victory);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(conn != null) conn.close();
			} catch(Exception e2) {
				e2.printStackTrace();
			}	
		} 
		return dto;
	}
	




	public void delete(String id) {
			try {
				String query = "delete from food_info where id = ?";
				preparedStatement = conn.prepareStatement(query);
				preparedStatement.setInt(1, Integer.parseInt(id));
				int rn = preparedStatement.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(preparedStatement != null) preparedStatement.close();
					if(conn != null) conn.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	
	public void wirte_out(String id) {
		try {
			String query = "insert into out_info (id, is_out) values ( ?, ?)";
			preparedStatement = conn.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(id));
			preparedStatement.setBoolean(2, false);
			int rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(conn != null) conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
		
}
	
	
	
