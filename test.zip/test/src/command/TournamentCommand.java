package command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import dto.Dto;

public class TournamentCommand implements Command{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		String location[] = request.getParameterValues("in_or_ex");
		for(int i=0; i<location.length; i++) {
			System.out.println(location[i]);			
		}
		String type[] = request.getParameterValues("category");
		for(int i=0; i<type.length; i++) {
			System.out.println(type[i]);
		}
		int price_down = Integer.parseInt(request.getParameter("min"));
		System.out.println(price_down);
		int price_up = Integer.parseInt(request.getParameter("max"));
		System.out.println(price_up);
		int portion = Integer.parseInt(request.getParameter("allowedunits"));
		System.out.println(portion);
		
		String str_location ="";
		String str_type="";
		
		for(int i=0; i<location.length; i++) {
			if(i==0) {
				str_location += " and ( location = ?";
			} else {
				str_location +=" or location = ? ";
			}
			if(i==location.length-1) str_location += " )";
		}
		
		System.out.println(str_location);
		
		for(int i=0; i<type.length; i++) {
			if(i==0) {
				str_type += " and ( type = ?";
			} else {
				str_type += " or type = ?";
			}
			if(i==type.length-1) str_type += " )";
		}
		
		System.out.println(str_type);

		ArrayList<Dto> dtos = new ArrayList<Dto>();
		Dao dao = new Dao();
		dtos = dao.makeList(str_location, str_type, location, type, price_up, price_down, portion);  /* ����Ʈ ����� */
		
		for(int i=0; i<dtos.size(); i++) {
			System.out.println(dtos.get(i).getId());
		}
		
		request.setAttribute("list", dtos);
		
	}
}