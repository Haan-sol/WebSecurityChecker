package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import dto.Dto;

public class ContentCommand implements Command{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		//System.out.println("id = " + id);
		Dao dao = new Dao();
		Dto dto = dao.content(id);
		request.setAttribute("content_view", dto);
		
		/* �̹����� ���� ���� DB�� ����� ��θ� ���� */
		String file = dto.getImgFile();
		request.setAttribute("file", file);
	}
}