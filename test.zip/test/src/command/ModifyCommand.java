package command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;

public class ModifyCommand implements Command{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("id"));
		String type = request.getParameter("type");
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String location = request.getParameter("location");
		boolean single = false;
		if(request.getParameter("single").equals("yes")) {
			single = true;
		} else if (request.getParameter("single").equals("no")) {
			single = false;
		}
		boolean delivery = false;
		if(request.getParameter("delivery").equals("yes")) {
			delivery = true;
		} else if (request.getParameter("delivery").equals("no")) {
			delivery = false;
		}
		int portion = Integer.parseInt(request.getParameter("portion"));
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String imgFile = request.getParameter("imgFile");
		int victory = Integer.parseInt(request.getParameter("victory"));
		
		Dao dao = new Dao();
		System.out.println("Modify Command");
		dao.modify(id, type, name, price, location, single, delivery, portion, phone, address, imgFile, victory);
		
		
		
	}
}