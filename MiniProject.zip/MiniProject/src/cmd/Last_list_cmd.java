package cmd;

import java.util.ArrayList;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Menu_dao;
import dto.Menu_dto;

public class Last_list_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		Menu_dao dao = new Menu_dao();
		System.out.println("last_list");
		ArrayList<Menu_dto> dtos;
		
		Cookie[] cookies = request.getCookies();
		String[] ids = new String[4];
		for(int i=0; i<4; i++) {		 
				 ids[i]=cookies[i].getValue();
		}
		
		System.out.println(" the length :" + ids.length);
		dtos = dao.selected_list(ids);
		request.setAttribute("list", dtos);
	}

}
