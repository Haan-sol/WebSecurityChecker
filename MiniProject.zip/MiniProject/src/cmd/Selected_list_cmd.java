package cmd;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Menu_dao;
import dto.Menu_dto;

public class Selected_list_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		Menu_dao dao = new Menu_dao();
		ArrayList<Menu_dto> dtos = new ArrayList<Menu_dto>();
		String types[] = request.getParameterValues("type");
		int minPrice = Integer.parseInt(request.getParameter("min"));
		int maxPrice = Integer.parseInt(request.getParameter("max"));
		String locations =request.getParameter("location");
		int portions = Integer.parseInt(request.getParameter("portion"));
		
		dtos = dao.selected_list(types, minPrice, maxPrice, locations, portions);
		
		for(int i=0; i < dtos.size(); i++) {
			System.out.println("one index " + i + " : value " + dtos.get(i).getName());
		}
		
		
		request.setAttribute("list", dtos);
	}

}
