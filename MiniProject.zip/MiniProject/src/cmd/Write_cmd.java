package cmd;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import cmd.Menu_cmd;
import dao.Menu_dao;

public class Write_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String path =request.getSession().getServletContext().getRealPath("IMG");
		System.out.println(path);
		int size = 1024 * 1024 * 10; //10M
		String file = "";
		String oriFile = "";
		
		try{
			MultipartRequest multi = new MultipartRequest(request, path, size, "EUC-KR", new DefaultFileRenamePolicy());
			
			Enumeration files = multi.getFileNames();
			String str = (String)files.nextElement();
			
			file = multi.getFilesystemName(str);
			oriFile = multi.getOriginalFileName(str);
			
			String type = multi.getParameter("type");
			String name = multi.getParameter("name");
			String price = multi.getParameter("price");
			String location = multi.getParameter("location");
			boolean single = multi.getParameter("single").equals("1");
			boolean delivery = multi.getParameter("delivery").equals("2");
			String portion = multi.getParameter("portion");
			String phone = multi.getParameter("phone");
			String address = multi.getParameter("address");
			String imgFile = file;
			System.out.println(type +" : " + name +" : " + price +" : " + location +" : " + single +" : " + delivery +" : " +portion +" : " + phone +" : " + address +" : " + imgFile);
			Menu_dao dao = new Menu_dao();
			dao.write(type, name, Integer.parseInt(price), location, single, delivery, Integer.parseInt(portion), phone, address, imgFile);
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("File Upload error");
		}
		
		
	}

}
