package cmd;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Menu_dao;

public class Victory_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		Menu_dao dao = new Menu_dao();
		dao.victory(id);
	}

}
