package cmd;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.Menu_dao;


public class Modify_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String type = request.getParameter("type");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String location = request.getParameter("location");
		String single = request.getParameter("single");
		String delivery = request.getParameter("delivery");
		String portion = request.getParameter("portion");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String imgFile = fileUpload(request);
		
		Menu_dao dao = new Menu_dao();
		dao.modify(Integer.parseInt(id),type, name, Integer.parseInt(price), location, Boolean.parseBoolean(single), Boolean.parseBoolean(delivery), Integer.parseInt(portion), phone, address, imgFile);

	}
	
	public String fileUpload(HttpServletRequest request) {
		
		String path =request.getSession().getServletContext().getRealPath("IMG");

		int size = 1024 * 1024 * 10; //10M
		String file = "";
		String oriFile = "";
		
		try{
			MultipartRequest multi = new MultipartRequest(request, path, size, "EUC-KR", new DefaultFileRenamePolicy());
			
			Enumeration files = multi.getFileNames();
			String str = (String)files.nextElement();
			
			file = multi.getFilesystemName(str);
			oriFile = multi.getOriginalFileName(str);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("File Upload error");
		}
		return file;
	}

}
