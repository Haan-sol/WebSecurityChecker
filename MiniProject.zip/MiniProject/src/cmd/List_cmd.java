package cmd;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Menu_dao;
import dto.Menu_dto;


public class List_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		Menu_dao dao = new Menu_dao();
		ArrayList<Menu_dto> dtos;
		String order = request.getParameter("order");
		if(order == null) {
			 dtos = dao.list();
		}else {
			 dtos = dao.list(order);
		}
		request.setAttribute("list", dtos);
	}

}
