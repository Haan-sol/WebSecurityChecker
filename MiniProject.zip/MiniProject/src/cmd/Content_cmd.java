package cmd;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Menu_dao;
import dto.Menu_dto;

public class Content_cmd implements Menu_cmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		Menu_dao dao = new Menu_dao();
		Menu_dto dto = dao.content(id);
		
		request.setAttribute("content", dto);
	}
}
