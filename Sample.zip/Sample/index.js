var Body = {
  setColor:function(backcolor, fontcolor){
    $('body').css('backgroundColor', backcolor);
    // target.color = fontcolor;
    $('body').css('color', fontcolor);
    //$('body'),css('backgroundColor', backcolor)
  }

}



function nightDayhandler(self){
  var body =document.querySelector('body').style;
  if(self.value === 'night'){
    Body.setColor('black', 'white');
    self.value = 'day';
  }else {
    Body.setColor('pink', 'black');
    self.value = 'night';
  }
}

var yaeger = {
  "First Name" : "Uigeo",
  "Last Name" : 'Moon',
  "Age" : 25,
  "HomeTown" : "Gunsan"
}

yaeger["ID"] = 21300267;
yaeger.showAll = function(){
  for (var i in yaeger) {
    console.log(this[i])
  }
}
